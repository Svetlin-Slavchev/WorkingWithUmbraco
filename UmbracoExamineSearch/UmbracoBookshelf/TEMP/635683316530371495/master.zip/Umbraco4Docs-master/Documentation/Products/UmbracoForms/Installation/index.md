#Installation and upgrading

##[Extending Umbraco with the Forms section](Installation.md)
Extend Umbraco with the form builder section in a few steps  

##[Configuring a license](license.md)
Getting Forms out of trial mode

##[Keeping Forms up to date](Upgrade.md)
Simple upgrade instructions