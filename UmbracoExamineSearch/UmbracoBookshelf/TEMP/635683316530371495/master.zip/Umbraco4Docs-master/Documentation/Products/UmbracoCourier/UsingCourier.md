#Using Courier

_Outlines the common gotchas, and the recommended way to work with Courier, to perform as smooth deployments of a Umbraco site as possible_

This document will try to outline what Courier does, why it does it, and how you can work with it to make your deployments as smooth as possible.
It will go through the following: 

- A high-level view of what Courier does
- Why it does that
- What it can and cannot do out of the box
- How to handle the initial deployment
- Working with courier on a day to day basis.


##What Courier does.
From a high-level view, Courier is pretty simple. You tell it to deploy an item from one site to another, and Courier then figures out what is needed
for that specific item to function on the site you want to transfer it to. 

When it has figured this out, it exports the selected item(s) and their dependencies to a folder, as xml files, along with any images, dlls, and so on. 

Optionally it can compare the packaged items as it finds them, to figure out they have actually changed since the last update, and will skip those that have. 

Finally, it will build a graph of the deployment, based on the order of dependencies, this means that courier knows that a for a document to be installed, it needs to have its document type, template, datatypes and so on present on the target website. 

So, in short it:

- Collects the items you tell it to
- Collects the dependencies of these items 
- Compares the items and depedencies to the target website. 
- Stores the entire collection of files and data
- Builds a graph of the deployment to ensure that things are installed in the right order
- Sends the files and data to the target site, which will then install them

##Why does it perform all those things? 
The objective of Courier is to move functioning items from once place to another, but due to the way Umbraco is built, this is not a trivial task.
Lets consider the amount of dependencies that goes into moving a document

- The document itself
- The document data
- Property Editors used to edit the document data
- The document type
- Datatypes used in the document type
- Dlls, files, settings, content referenced by datatypes, like the RTE, and the content picker
- The template
- Css, js and images referenced in the template
- macros in the template
- document ids passed as paramereters to the macro, which leads to another document its data and so on.

We can sort these things into hard and soft dependencies, the hard ones are document type, data types and template, without these, the document
cannot exist in the database, due to ID references. 

The soft ones are all the items that make the page and editor actually work, so if you try to view a page without a template, it breaks, try to edit
a document with a datatype missing its configuration or a needed dll, it breaks. 

So the short version is, you dont want to miss those dependencies, because your site wont work, and you will have no idea why. 

##What can and cannot courier do.
The whole idea of Courier, builds around the idea of dependencies and references, which courier can understand to a certain degree.
But there are several areas, where courier have zero chance of understanding what is going an. 

###When a datatype stores node ids
Common thing, a data type stores a node ID, but courier doesnt know, so it cannot add the document as a dependency, and it cannot convert it into
a guid, so it will be transferable, however, you can add the datatype to the courier.config to tell courier to look for ids and convert them

###Data in external tables are referenced.
Courier doesnt know about it, cant deploy it, you can write your own provider for it, but this provides you with overhead, and it would
be better if you structured your external data so it can be moveable (avoid IDENTITY and so on.)

###You try to transfer really large files
Hard to spot, but if a changeset contains large files, and you try to transfer these over a webservice connection
it will die, you can increase the request limit and so, but it wont ever be 100% solid to do, so better to zip your
revision files and xcopy them over, when you need to deploy really large things


##How to handle the initial deployment
A common scenarion seen, is that people try to transfer their entire site in one go, to do the initial deploy. This is not recommended, and really just adds
unnneeded overhead to your deployment. Courier adds a lot of extra data and overhead, because it needs to convert to a format that be transfered and
referenced between the 2 sites, it also needs to compare data with this other site and determine which items should transfer, and which should not, finally it
all happens over http, which is another bottleneck

So In short, when you initially want to deploy your site, and dont have 2 environments to sync, just deploy your files and database as normally, and let courier handle the ongoing day-to-day changes which you subsequently will have to deploy. 


##Day to day work with Courier
Due to courier handling pretty much every object of your site, it can quickly create some rather large deployments, even tho your editors just want to deploy a single document, they can all of sudden have a deployment with a lot of documents and files in them, due to the whole dependency setup, there is not many ways aroud this currently, Courier will check for dependencies, and it will include those that have changed, as it is right now. 

But for day to day work, let your developers handle deployments of document types, templates and so on, and do these in small batches, as even minor changes do have a great effect on your Umbraco database, f.ex. if you add a propertytype to a document type, that will add an additional row for each document version on your site to the property data table, so even small things can mean big changes.

When your infrastructure (documnet types, templates, etc) is in place, your editors should in most cases not be bothered with too many big deployments using the right-click menu, Courier will try to skip as many things as possible, and only suggest things that have actually changed, but as you have probably guessed by now, this is no simple task. 

##Ongoing finetuning
We do finetune this process all the time, to cater to all the different ways an Umbraco site can be built, some scenarios we simply cant support out of the box, and some we can add configuration options for so it can fit with as many sites as possible. 

Let us know in the Courier forum on Our, if certain scearions or setups give unreasonable large deployments, provide as many details as possible, or even better, provide us with a database backup, so we can try it out on our local machines and adjust the many variables. 


