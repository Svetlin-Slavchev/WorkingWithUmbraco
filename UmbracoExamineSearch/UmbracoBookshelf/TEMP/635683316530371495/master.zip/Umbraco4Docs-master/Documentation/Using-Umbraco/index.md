#Using Umbraco

###[Back Office Overview](Backoffice-Overview/index.md)

Details of all the common terms and concepts that are used throughout the Umbraco backoffice.

###[Creating a basic site with Umbraco](Creating-Basic-Site/index.md)

Step by step guide of everything you need to get a basic site up and running in Umbraco.

###[Configuration Files](Config-files/index.md)

An explanation of what all the config files do.


###[Multi language Setup](Multilanguage-Setup/index.md)

Tips and methods for creating multi lingual websites.