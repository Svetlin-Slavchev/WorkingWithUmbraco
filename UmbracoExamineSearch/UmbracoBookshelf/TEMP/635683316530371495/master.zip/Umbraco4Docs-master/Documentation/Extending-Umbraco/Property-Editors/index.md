#Property Editors

A property editor is the editor used to insert content into Umbraco. [See here for definition.](../using-umbraco/backoffice-overview/property-editors/index.md) 

##[Property Editors in v7](property-editors-v7.md)

This section describes how to work with and create Property Editors in v7

##[Property Editors in v6 (and v4)](property-editors-v6.md)

This section describes how to work with and create Property Editors in v6 (and v4)