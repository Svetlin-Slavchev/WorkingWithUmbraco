# Searching
_Search in Umbraco cam be implemented in several ways. Out of the box, Umbraco 4 supports 2 methods: Examine, which is a lucene implementation for Umbraco, and XsltSearch which is an easy to use searcher for small sites._


## [Examine](Examine/index.md)
Walkthrough of the many options and settings in Examine for Umbraco 4.
