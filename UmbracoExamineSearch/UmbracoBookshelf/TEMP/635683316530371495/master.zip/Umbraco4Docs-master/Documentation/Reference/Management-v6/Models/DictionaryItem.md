#DictionaryItem / DictionaryTranslation

**Applies to Umbraco 6.x and newer**

Intro text here.

 * **Namespace:** `Umbraco.Core.Models` 
 * **Assembly:** `Umbraco.Core.dll`

All samples in this document will require references to the following dll:

* Umbraco.Core.dll

All samples in this document will require the following usings:
	
	using Umbraco.Core.Models;

##Constructors

##Properties

##Methods