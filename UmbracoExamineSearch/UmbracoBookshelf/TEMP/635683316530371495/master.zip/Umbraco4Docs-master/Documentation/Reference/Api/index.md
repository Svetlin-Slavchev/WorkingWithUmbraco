#Umbraco 4 API

##[/Base](Base/Index.md)
/Base is a extendable system for creating raw feeds directly from Umbraco using very basic Url's. This enables developers to access Umbraco data through javascript, f.ex or flash.

##[Umbraco.Library](UmbracoLibrary/index.md)
Umbraco.Library is a Xslt extension library, built specifically for xslt macros in Umbraco 4. It contains many utility methods which are strictly for use in Xslt, but also has a number of more general purpous methods, which can used more broadly.