#Managing macros

_Describes how to create/update a macro and its parameters_

##Creating macros

There are a couple of ways to create a macro. The first way is to manually create a macro in the macro tree in the developer section:

![Create macro](images/create-macro-tree.png?raw=true)

Give it a name in the dialog screen, and then you'll be presented with the macro editor:

![Macro editor](images/macro-editor.png?raw=true)
