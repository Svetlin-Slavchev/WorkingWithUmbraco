#How Umbraco uses XSLT
Umbraco utilizes XSLT to dynamically render content such as navigational structures, lists, and nearly anything you can dream of.  This is accomplished through the use of Macros.

##Creating Your First XSLT Macro
Creating an XSLT macro is very easy.

1. Go to the developers section in the administration area.
2. Right click on the XSLT folder, and select create.
3. You will receive a dialog where you can specify the name, select an XSLT template, and specify if you want to automatically create the Macro for this template.
4. Specify the name of the new XSLT file, check Create Macro, and select a template if you desire. Click Create.
5. You have now created the XSLT file and the Macro for rendering the content.

Now that we have the XSLT created, we need to customize it to output our content the way we like.

**Note: I have copied the original book from Casey Neehouse from the books section of umbraco.org**

