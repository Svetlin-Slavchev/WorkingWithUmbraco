#Snippets

If you have a quick and useful XSLT snippet please create a new subpage with your example code snippet and try to explain in detail what it does so beginners to XSLT can understand what it is doing.