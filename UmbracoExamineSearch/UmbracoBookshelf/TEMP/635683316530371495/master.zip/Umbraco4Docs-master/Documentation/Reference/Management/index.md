#Developers Reference

The intended audience for these reference pages are .net developers, it is assumed the reader already has a knowledge of the basics of Umbraco and knows .net & c#


##[Content Types](ContentTypes/index.md)
Content Types, defines the data you work with, use the DocumentType and MediaType APIs to define what values editors can add to your pages.  **Coming soon**

##[Documents](Documents/index.md)
Create, Update, Move, Copy, delete and publish documents. 

##[Media](Media/index.md)
Create, Update, Move, Copy and delete media. 

##[Members](Members/index.md)
Create, Update, Move, Copy, assign groups and delete members. **Coming soon**

##[Relations](Relations/index.md)
Creating and finding relations between Umbraco items.

##[Templates](Templates/index.md)
Create templates programatically  **Coming soon**