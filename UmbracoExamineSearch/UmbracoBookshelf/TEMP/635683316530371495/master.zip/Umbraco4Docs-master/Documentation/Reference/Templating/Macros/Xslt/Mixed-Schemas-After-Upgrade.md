# Mixed schemas after upgrade

There are some cases where the upgrade process doesn't reflect all nodes so that you might have a mixed umbraco.config. In this case republish the site via

    http://yourdomain.com/umbraco/dialogs/republish.aspx?xml=true

and clicking the "republish the entire site" button.
