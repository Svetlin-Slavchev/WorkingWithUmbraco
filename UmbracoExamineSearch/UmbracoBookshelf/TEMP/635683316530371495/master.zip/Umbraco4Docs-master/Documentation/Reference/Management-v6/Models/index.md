#Developers Reference

The intended audience for these reference pages are .net developers, it is assumed the reader already has a knowledge of the basics of Umbraco and knows .net & c#.

The links listed below are api references for Umbraco's public model.

##[Content](Content.md)
API refence for the Content class. 

##[ContentType](ContentType.md)
API refence for the ContentType class. 

##[DataTypeDefinition](DataTypeDefinition.md)
API refence for the DataTypeDefinition class.

##DictionaryItem
API refence for the DictionaryItem and DictionaryTranslation classes.

##Language
API refence for the Language class.

##[Media](Media.md)
API refence for the Media class. 

##[MediaType](MediaType.md)
API refence for the MediaType class.

##Relation
API refence for the Relation class.

##RelationType
API refence for the RelationType class.

##Task
API refence for the Task class.

##TaskType
API refence for the TaskType class.

##Template
API refence for the Template class.