#Upgrading existing installs

_Covers the steps to upgrade your copy of Umbraco to a newer version._

##[In general](general.md)
Usually, upgrading involves just copying a few files and updating config files.

##[Version specific](version-specific.md)
This lists extra steps you need to take for each version since 4.6.1.
